package at.wifi.swdev.kostenrechner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KostenrechnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
