package at.wifi.swdev.kostenrechner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KostenrechnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KostenrechnerApplication.class, args);
	}

}
