package at.wifi.swdev.rechteck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RechteckApplicationTests {

	@Test
	void contextLoads() {
	}

}
